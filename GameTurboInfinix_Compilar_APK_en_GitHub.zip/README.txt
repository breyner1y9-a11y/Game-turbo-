GAME TURBO INFINIX - proyecto Android Studio

Funciones:
- Selector de aplicaciones instaladas.
- Botón flotante “GT” arrastrable y panel superpuesto.
- Acceso a ajustes de pantalla y batería.
- Opción FPS/pantalla que informa la frecuencia de refresco del sistema en Hz y advierte que no equivale a los FPS reales del juego.
- Preparar memoria: guía para cerrar manualmente apps, activar No molestar y reducir tareas en segundo plano.
- Consejos de sensibilidad.
- Acceso al permiso oficial de Android “Aparecer sobre otras apps”.
- No requiere root.

Cómo compilar:
1. Descomprime el ZIP.
2. Abre la carpeta GameTurboInfinix en Android Studio.
3. Usa JDK 17 y Android SDK 35; espera a que termine Gradle Sync.
4. Selecciona Build > Build APK(s).
5. El APK de depuración suele quedar en app/build/outputs/apk/debug/.

Cómo usar:
1. Instala y abre Game Turbo.
2. Elige el juego.
3. Activa “Permitir aparecer sobre otras apps” en Ajustes.
4. Vuelve y activa el botón flotante.
5. Entra al juego y toca el círculo GT.

Limitaciones:
- La frecuencia de pantalla en Hz NO es una medición de FPS de Free Fire.
- Android no ofrece a una app normal acceso universal a los FPS de otra app.
- El modo rendimiento abre ajustes del sistema; no puede forzar cambios bloqueados por el fabricante.
- Android no permite forzar el cierre de otras aplicaciones desde una app normal.

BUILD ONLINE WITHOUT ANDROID STUDIO (GitHub Actions):
1. Create a GitHub repository and upload all files/folders from this project to its main branch.
2. Open the repository's Actions tab.
3. Select "Build Game Turbo APK" and tap "Run workflow" if it did not start automatically.
4. Open the completed workflow run, find Artifacts, and download "GameTurbo-debug-apk".
5. Extract the downloaded artifact ZIP to obtain app-debug.apk, then install it on Android.
The APK is a debug build; Android may ask you to allow installation from that browser/file manager.
