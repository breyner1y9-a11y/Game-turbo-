package com.bonux.gameturbo

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun overlayType(): Int =
        if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "GT"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(124, 92, 255))
                setStroke(3, Color.rgb(0, 229, 255))
            }
            elevation = 10f
            setOnClickListener { togglePanel() }
            setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f
                var downY = 0f
                var startX = 0
                var startY = 0
                var moved = false
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    val p = bubbleParams ?: return false
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = event.rawX; downY = event.rawY
                            startX = p.x; startY = p.y; moved = false
                            return true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (event.rawX - downX).toInt()
                            val dy = (event.rawY - downY).toInt()
                            if (kotlin.math.abs(dx) > 6 || kotlin.math.abs(dy) > 6) moved = true
                            p.x = startX + dx; p.y = startY + dy
                            wm.updateViewLayout(b, p)
                            return true
                        }
                        MotionEvent.ACTION_UP -> {
                            if (!moved) v.performClick()
                            return true
                        }
                    }
                    return false
                }
            })
        }
        val params = WindowManager.LayoutParams(
            dp(54), dp(54), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12); y = dp(180)
        }
        bubble = b
        bubbleParams = params
        wm.addView(b, params)
    }

    private fun togglePanel() {
        if (panel != null) {
            removePanel()
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.rgb(18, 20, 42))
                cornerRadius = dp(18).toFloat()
                setStroke(dp(2), Color.rgb(0, 229, 255))
            }
        }
        val title = TextView(this).apply {
            text = "🎮 GAME TURBO"
            textSize = 18f
            setTextColor(Color.rgb(0, 229, 255))
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(8))
        }
        box.addView(title)
        box.addView(actionButton("Elegir juego") {
            removePanel()
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        })
        box.addView(actionButton("Abrir juego seleccionado") { launchSelected() })
        box.addView(actionButton("Ajustes de batería") {
            removePanel()
            openSettings(android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS)
        })
        box.addView(actionButton("Ajustes de pantalla") {
            removePanel()
            openSettings(android.provider.Settings.ACTION_DISPLAY_SETTINGS)
        })
        box.addView(actionButton("Preparar memoria") {
            Toast.makeText(this, "Cierra manualmente las apps que no uses, activa No molestar y deja enfriar el teléfono. Android no permite a esta app forzar el cierre de otras aplicaciones.", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
        })
        box.addView(actionButton("FPS / pantalla") {
            val refresh = try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                @Suppress("DEPRECATION")
                wm.defaultDisplay.refreshRate
            } catch (_: Exception) { 0f }
            val hz = if (refresh > 0f) String.format(java.util.Locale.US, "%.0f Hz", refresh) else "no disponible"
            Toast.makeText(this, "Frecuencia de pantalla del sistema: $hz. Esto NO es una medición de los FPS de Free Fire. Para FPS reales, usa el contador del juego o una herramienta compatible del sistema.", Toast.LENGTH_LONG).show()
        })
        box.addView(actionButton("Consejos de sensibilidad") {
            Toast.makeText(this, "Ajusta la sensibilidad dentro del juego poco a poco y prueba en entrenamiento.", Toast.LENGTH_LONG).show()
        })
        box.addView(actionButton("Permiso de superposición") {
            removePanel()
            val i = Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        })
        box.addView(actionButton("Cerrar menú") { removePanel() })
        box.addView(actionButton("Ocultar botón flotante") { stopSelf() })
        val params = WindowManager.LayoutParams(
            dp(240), WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12); y = dp(245)
        }
        panel = box
        panelParams = params
        wm.addView(box, params)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(75, 58, 150))
        setOnClickListener { action() }
    }

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun launchSelected() {
        val prefs = getSharedPreferences("game_turbo", Context.MODE_PRIVATE)
        val pkg = prefs.getString("selected_package", null)
        if (pkg == null) {
            Toast.makeText(this, "Abre Game Turbo y elige un juego primero.", Toast.LENGTH_LONG).show()
            return
        }
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) {
            Toast.makeText(this, "No se pudo abrir el juego.", Toast.LENGTH_SHORT).show()
        } else {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        panelParams = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        removePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        bubbleParams = null
        super.onDestroy()
    }
}
