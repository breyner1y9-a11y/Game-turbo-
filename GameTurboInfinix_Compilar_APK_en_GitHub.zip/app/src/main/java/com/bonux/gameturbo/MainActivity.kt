package com.bonux.gameturbo

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("game_turbo", Context.MODE_PRIVATE) }
    private var selectedPackage: String?
        get() = prefs.getString("selected_package", null)
        set(value) { prefs.edit().putString("selected_package", value).apply() }
    private var selectedLabel: String?
        get() = prefs.getString("selected_label", null)
        set(value) { prefs.edit().putString("selected_label", value).apply() }
    private lateinit var selectedText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(Color.rgb(12, 13, 28))
        }
        val title = TextView(this).apply {
            text = "GAME TURBO"
            textSize = 28f
            setTextColor(Color.rgb(0, 229, 255))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Modo de juego • Infinix SMART 10"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 26)
        }
        selectedText = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 22)
        }
        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(selectedText, matchWrap())
        root.addView(makeButton("🎮 Elegir juego", Color.rgb(124, 92, 255)) { showAppPicker() }, buttonParams())
        root.addView(makeButton("🪟 Permitir aparecer sobre otras apps", Color.rgb(42, 48, 72)) { requestOverlayPermission() }, buttonParams())
        root.addView(makeButton("🟣 Activar botón flotante", Color.rgb(0, 130, 150)) { startFloating() }, buttonParams())
        root.addView(makeButton("🚀 Abrir juego seleccionado", Color.rgb(36, 115, 72)) { launchSelectedGame() }, buttonParams())
        root.addView(makeButton("🔋 Ajustes de batería", Color.rgb(75, 65, 90)) { openBatterySettings() }, buttonParams())
        root.addView(makeButton("🖥️ Ajustes de pantalla", Color.rgb(55, 70, 95)) { openDisplaySettings() }, buttonParams())
        root.addView(makeButton("🎯 Consejos de sensibilidad", Color.rgb(95, 65, 120)) { showSensitivityTips() }, buttonParams())
        root.addView(makeButton("🧹 Preparar el teléfono para jugar", Color.rgb(85, 75, 95)) {
            AlertDialog.Builder(this)
                .setTitle("Preparar memoria")
                .setMessage("Antes de jugar: cierra manualmente apps que no uses, activa No molestar, desactiva descargas en segundo plano y deja enfriar el teléfono. Esta app no puede forzar el cierre de otras apps.")
                .setPositiveButton("Abrir ajustes") { _, _ ->
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
                .setNegativeButton("Listo", null)
                .show()
        }, buttonParams())
        val note = TextView(this).apply {
            text = "Nota: esta app ofrece accesos rápidos y un menú flotante. Android no permite aumentar FPS por arte de magia ni forzar el cierre de todas las apps. El resultado depende del juego, temperatura y límites del teléfono."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 20, 0, 0)
        }
        root.addView(note, matchWrap())
        setContentView(root)
        refreshSelected()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
    private fun buttonParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 7, 0, 7) }

    private fun makeButton(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setBackgroundColor(color)
        setOnClickListener { action() }
    }

    private fun refreshSelected() {
        selectedText.text = if (selectedPackage == null) {
            "Juego seleccionado: ninguno"
        } else {
            "Juego seleccionado: ${selectedLabel ?: selectedPackage}"
        }
    }

    private fun showAppPicker() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        if (apps.isEmpty()) {
            Toast.makeText(this, "No se encontraron aplicaciones para elegir.", Toast.LENGTH_LONG).show()
            return
        }
        val labels = apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Elige un juego o aplicación")
            .setItems(labels) { _, which ->
                selectedPackage = apps[which].activityInfo.packageName
                selectedLabel = labels[which]
                refreshSelected()
                Toast.makeText(this, "Seleccionado: ${labels[which]}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "El permiso de superposición ya está activado.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun startFloating() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Primero activa el permiso para aparecer sobre otras apps.", Toast.LENGTH_LONG).show()
            requestOverlayPermission()
            return
        }
        startService(Intent(this, FloatingService::class.java))
        Toast.makeText(this, "Botón flotante activado.", Toast.LENGTH_SHORT).show()
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun openDisplaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun showSensitivityTips() {
        AlertDialog.Builder(this)
            .setTitle("Consejos de sensibilidad")
            .setMessage("No existe una sensibilidad perfecta para todos. Prueba cambios pequeños dentro del juego y entrena en el campo de práctica. Mantén los FPS estables, evita que el teléfono se caliente y no compartas tu cuenta con apps que prometan mejorar la puntería.")
            .setPositiveButton("Entendido", null)
            .show()
    }

    private fun launchSelectedGame() {
        val pkg = selectedPackage
        if (pkg == null) {
            Toast.makeText(this, "Primero elige un juego.", Toast.LENGTH_SHORT).show()
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) {
            Toast.makeText(this, "No se pudo abrir esa aplicación.", Toast.LENGTH_SHORT).show()
            return
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
    }
}
