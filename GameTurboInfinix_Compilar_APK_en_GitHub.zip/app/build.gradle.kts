plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.bonux.gameturbo"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.bonux.gameturbo"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
